<?php
if(isset($_POST['contactFrmSubmit']) && !empty($_POST['name']) && !empty($_POST['email']) && (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false) && !empty($_POST['message'])){
    
    // Submitted form data
    $name   = $_POST['name'];
    $email  = $_POST['email'];
    $phone  = $_POST['phone'];
    $message= $_POST['message'];
    
    /*
     * Send email to admin
     */
    $to     = 'rajnish@realtimesig.com ';
    $subject= 'Contact Request Submitted';
    
    $htmlContent ='
    Request Details
    
            Name:'.$name.'
            
            Email:'.$email.'
            
            Phone:'.$phone.'
            
            Message:'.$message.'
        ';
    
    // Set content-type header for sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
   
    
     // Additional headers
    $headers = "From: $name";
    // Send email
    if(mail($to,$subject,$htmlContent,$headers)){
        $status = 'ok';
    }else{
        $status = 'err';
    }
    
    // Output status
    echo $status;die;
}